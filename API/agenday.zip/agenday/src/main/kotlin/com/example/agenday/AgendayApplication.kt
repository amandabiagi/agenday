package com.example.agenday

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class AgendayApplication

fun main(args: Array<String>) {
	runApplication<AgendayApplication>(*args)
}
